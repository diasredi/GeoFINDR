#!/bin/bash
date
echo "tolerance exp"
python3 main_SMEU_tolerance.py > ./resultats\ experiences/experience-article/output-tolerance.txt
date
echo "zonesize exp"
python3 main_SMEU_zonesize.py > ./resultats\ experiences/experience-article/output-zonesize.txt
date
echo "nblm exp"
python3 main_SMEU_nblm.py > ./resultats\ experiences/experience-article/output-nblm.txt
date
echo "interval exp"
python3 main_SMEU_interval.py > ./resultats\ experiences/experience-article/output-interval.txt
date
echo "finished"
