import csv #useless
#code files
import choixlm
import distance_delai
#import necessary environment values
from environment_values import tolerance, zone_size, sector_lm_nb, declared_position, real_latitude, real_longitude, interval_percent
import recup_liste_lm
import triangulation
import time
import math


#A MODIFIER CA MARCHERA PAS COMME CA, INTERVAL N'EST PAS INTEGRE DANS LE MAIN !

########
# GET LM list
########

landmarks_source = recup_liste_lm.import_landmarks()
landmarks = landmarks_source


#EUcapitales = [("Evry_real",48.625 , 2.443),("Amsterdam",52.3738 , 4.8910),("Tirana",41.3317 , 19.8172),("Andorra la Vella",42.5075 , 1.5218),("Vienna",48.2092 , 16.3728),("Minsk",53.9678 , 27.5766),("Brussels",50.8371 , 4.3676),("Sarajevo",43.8608 , 18.4214),("Sofia",42.7105 , 23.3238),("Zagreb",45.8150 , 15.9785),("Prague",50.0878 , 14.4205),("Copenhagen",55.6763 , 12.5681),("Tallinn",59.4389 , 24.7545),("Helsinki",60.1699 , 24.9384),("Paris",48.8567 , 2.3510),("Berlin",52.5235 , 13.4115),("Athens",37.9792 , 23.7166),("Budapest",47.4984 , 19.0408),("Reykjavik",64.1353 , -21.8952),("Dublin",53.3441 , -6.2675),("Rome",41.8955 , 12.4823),("Pristina",42.6740 , 21.1788),("Riga",56.9465 , 24.1049),("Vaduz",47.1411 , 9.5215),("Vilnius",54.6896 , 25.2799),("Luxembourg",49.6100 , 6.1296),("Valletta",35.9042 , 14.5189),("Chisinau",47.0167 , 28.8497),("Monaco",43.7325 , 7.4189),("Podgorica",42.4602 , 19.2595),("Skopje",42.0024 , 21.4361),("Oslo",59.9138 , 10.7387),("Warsaw",52.2297 , 21.0122),("Lisbon",38.7072 , -9.1355),("Bucharest",44.4479 , 26.0979),("Moscow",55.7558 , 37.6176),("San Marino",43.9424 , 12.4578),("Belgrade",44.8048 , 20.4781),("Bratislava",48.2116 , 17.1547),("Ljubljana",46.0514 , 14.5060),("Madrid",40.4167 , -3.7033),("Stockholm",59.3328 , 18.0645),("Bern",46.9480 , 7.4481),("Kiev",50.4422 , 30.5367),("London",51.5002 , -0.1262),("Torshavn",62.0177 , -6.7719),("Gibraltar",36.1377 , -5.3453),("Saint Peter Port",49.4660 , -2.5522),("Douglas",54.1670 , -4.4821),("Saint Helier",49.1919 , -2.1071),("Longyearbyen",78.2186 , 15.6488)]

world_capitales = [("Evry_real",48.625 , 2.443),("Amsterdam",52.3738 , 4.8910),("Tirana",41.3317 , 19.8172),("Andorra la Vella",42.5075 , 1.5218),("Helsinki",60.1699 , 24.9384),("Paris",48.8567 , 2.3510),("Berlin",52.5235 , 13.4115),("Budapest",47.4984 , 19.0408),("Reykjavik",64.1353 , -21.8952),("Rome",41.8955 , 12.4823),("Warsaw",52.2297 , 21.0122),("Lisbon",38.7072 , -9.1355),("Moscow",55.7558 , 37.6176),("Madrid",40.4167 , -3.7033),("Stockholm",59.3328 , 18.0645),("Bern",46.9480 , 7.4481),("London",51.5002 , -0.1262),("Torshavn",62.0177 , -6.7719),("Tokyo",35.68,139.77),("Melbourne",-37.845,145.0),("Dubai",25.188,55.250),("Buenos Aires",-34.645,-58.401),("Los Angeles",33.940,-118.217),("Kinshasa",-4.36,15.313)]

for interval in range(5,110,10):
	interval_percent = interval/100


	capital_nb = 0
	for capital in world_capitales: #experimental loop ex:for all latitude / longitudes european capital cities
		capital_nb+=1
		print("\n---------------------------")
		print(" NEW POSITION ESTIMATION :")
		print("---------------------------\n")

		declared_position = (capital[1],capital[2])
		print("CAPITAL : ",capital[0])

		print("Declared position : ", declared_position)


		initial_position = declared_position

		size_min_zone = 0

		latest_sector = initial_position

		start_time = time.time()
		for nb_iterations in range(15):


			#PART 1 SECTOR ESTIMATION
			print("Sector estimation STEP ",nb_iterations,"\n--------\n")

			#near landmarks for triangulation : def landmarks_proches(landmarks, nombre, zone_size, declared_position)
			#return nb_zone to get number of available LMs in zone_size around position
			nearest_landmarks, nb_zone = choixlm.landmarks_proches(landmarks, sector_lm_nb, zone_size, initial_position, size_min_zone)

			#if not enough LMs in zone, extend zone
			while nb_zone < sector_lm_nb:
				
				zone_size = zone_size + tolerance
				nearest_landmarks, nb_zone = choixlm.landmarks_proches(landmarks, sector_lm_nb, zone_size, initial_position, size_min_zone)

			print(nb_zone, "landmarks in zone of ", zone_size, "km, for sector estimation")

			#choice dispersed LMs among nearest : def choix_lm(landmarks, nombre)
			selected_landmarks = choixlm.choix_lm(nearest_landmarks, sector_lm_nb)
			print("choosen landmarks : ",[lm.name for lm in selected_landmarks])

			#find the number of probes occurences>1
			included = distance_delai.corresponding_landmarks_delays(selected_landmarks,landmarks,interval_percent)
			
			#counting results
			dict_results = {-1:0} 
			for elem in included :
				for e in elem:
					if e in dict_results:
						dict_results[e] = dict_results[e]+1
					else:
						dict_results[e] = 1

			#Error if no result found
			print("number of failed measures ",dict_results[-1])
			if sector_lm_nb-dict_results[-1]<1 :
				print("Failed sector estimation not enough valid measures")
				break

			#sort results by most similar
			sorted_results = dict(sorted(dict_results.items(), key=lambda x:x[1], reverse=True))
			print(sorted_results)
			fails = sorted_results.pop(-1)

			#obtaining the list of most similar anchors ID
			max_key_id = max(sorted_results, key=lambda key: sorted_results[key])

			correlated_ids = [key for key in sorted_results if sorted_results[key]==sorted_results[max_key_id] and key!=-1]
			print("\nID(s) of most similar anchors : ",[lm.name for lm in distance_delai.get_landmark_objects_from_ids(correlated_ids, landmarks)])
			if (sector_lm_nb-fails)>0:
				print("Coefficient of similarity (occurrences / number of tests) : ",sorted_results[max_key_id]/(sector_lm_nb-fails))
			else:
				print("Coefficient of similarity (occurrences / number of tests) : all failed")

			#sector position = average of similar anchors position A MODIFIER
			#th = ((sector_lm_nb-dict_results[-1])/2)-2
			#if sorted_results[max_key_id]<th:
			#	th = sorted_results[max_key_id]-1
			th = sorted_results[max_key_id]-1
			sector_lat, sector_long = distance_delai.weighted_average_position(sorted_results,landmarks,threshold=th) 
			#sector position is baricenter
			lms = distance_delai.get_landmark_objects_from_ids(correlated_ids, landmarks)
			sector_lat, sector_long, distances, eqm = distance_delai.find_baricenter(lms)
			print("baricenter values : ",(distances,eqm))


			print("new estimated sector : (", sector_lat,", ", sector_long,")")
			
			#if positions converges, continue
			if triangulation.great_circle_distance(latest_sector[0],latest_sector[1], sector_lat, sector_long)<tolerance:
				break
			else:
				#else try again with new position
				initial_position = (sector_lat,sector_long)
				latest_sector = initial_position

		end_time = time.time()

		#Display results in console : position, distance declared position (SLA respected ?), uncertain delay, reqm
		print("\n---------------------------")
		print(" WRAP UP :")
		print("---------------------------\n")
		audit_time = end_time-start_time
		print("TIME OF AUDIT = ", audit_time)

		print("Declared position in SLA : ",declared_position)

		print("\nTolerance = ",tolerance,"; Zone's size = ",zone_size, "; Number of choosen landmarks = ",sector_lm_nb, "; Selected delay interval percent  = ",interval_percent)

		print("\nRESULTS :")
		print("-----------\n")


		#sector position 
		print("Sector position : (", sector_lat,", ", sector_long,")\n")
		print("ID(s) of most similar anchors : ",correlated_ids)
		if (sector_lm_nb-dict_results[-1])>0:
			print("Coefficient of similarity (occurrences / number of tests) : ",sorted_results[max_key_id]/(sector_lm_nb-dict_results[-1]))
		else:
			print("Coefficient of similarity (occurrences / number of tests) : 0")
		print("Number of for latest estimation : ", dict_results[-1])
		print("Number of iterations : ",nb_iterations+1)



		#EXPERIMENT, if the real latitude and longitude are set, display the distance between real position and estimated sector
		if real_latitude != None and real_longitude != None:
			real_position = (real_latitude, real_longitude)
			dist_estimation_real = triangulation.great_circle_distance(real_position[0], real_position[1], sector_lat, sector_long)
			print("EXPERIMENTAL : distance beetween real and sector position in km : ",dist_estimation_real)
			
			#dist_estimation_declared,eqm = 0,0
			dist_estimation_declared = triangulation.great_circle_distance(sector_lat, sector_long,declared_position[0],declared_position[1])
			print("EXPERIMENTAL : distance beetween declared and estimated position in km : ",dist_estimation_declared)

			anchors_paris = ['6921','6981','6960','6830','6333','6846','6666','6728','7042','7134','7067','7286','7146','6817', '6564', '7202']
			print("anchors en region parisienne selectionnes : ", [i for i in correlated_ids if str(i) in anchors_paris])
			print("anchors pas en region parisienne selectionnes : ", [i for i in correlated_ids if str(i) not in anchors_paris])

			path_results = r"results_interval_world.csv"
			dist_real_declared = triangulation.great_circle_distance(real_position[0], real_position[1], declared_position[0],declared_position[1])
			smre = math.sqrt(eqm)
			new_line = [interval,dist_real_declared,dist_estimation_declared,dist_estimation_real,smre, nb_iterations+1,audit_time ,capital[0]]
			
			with open(path_results,'a') as f:
				writer = csv.writer(f,delimiter=',')
				if capital_nb == 1 :
					writer.writerow(["interval","dist_real_declared","dist_estimation_declared","dist_estimation_real","smre","nb_iterations","audit_time","capitale"])
				writer.writerow(new_line)
